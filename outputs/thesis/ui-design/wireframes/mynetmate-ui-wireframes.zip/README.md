# MyNetMate — Editable UI Wireframes

ไฟล์หลัก: [mynetmate-ui-wireframes.drawio](mynetmate-ui-wireframes.drawio)

เปิดด้วย diagrams.net / Draw.io แล้วเลือกแท็บด้านล่างของไฟล์ แต่ละข้อความ ปุ่ม ช่องกรอก ตาราง และเส้นเชื่อมเป็นองค์ประกอบที่แก้ไขหรือย้ายได้ ไม่ใช่ภาพหน้าจอที่ฝังรวมเป็นก้อนเดียว

## หน้าจอในไฟล์

1. Login
2. Dashboard — แบบร่างเสนอข้อมูลสรุป ไม่ใช่หน้าปัจจุบันที่ยังเป็น Empty Page
3. Device Inventory
4. Device Details
5. Add Device
6. Edit Device — เปิดจาก Actions ของ Inventory; Admin/Operator แก้ข้อมูลประกอบและ Management State; Reachability อ่านอย่างเดียว
7. Network Discovery
8. Topology
9. User Management
10. Create User
11. Edit User
12. Audit History
13. Audit Event Details

## การใช้งาน

- ดับเบิลคลิกข้อความเพื่อแก้ไข ลากกล่องเพื่อปรับตำแหน่ง และลากจุดจับเพื่อเปลี่ยนขนาด
- ใช้แท็บด้านล่างเพื่อเลือกหน้าจอ หรือ Duplicate Page เพื่อทำแบบทางเลือก
- PNG ใช้ใส่เอกสาร ส่วน SVG ใช้เมื่อต้องการขยายภาพ และ `.drawio` แยกใช้เมื่อส่งให้เพื่อนแก้เฉพาะหน้า
- ภาพรวม: [wireframes-overview.png](wireframes-overview.png)
- Wireframe นี้ไม่ได้จำลองการกดปุ่มทำงานจริง การใช้แท็บคือการเลือกภาพ ไม่ใช่ Prototype ที่เชื่อมกับ Backend

## ขอบเขตและข้อควรทราบ

- ครอบคลุมเฉพาะ Network Management ไม่รวม Configuration Management
- เป็นภาพ Low-fidelity เพื่อคุยเรื่องโครงหน้าและตำแหน่งองค์ประกอบ ไม่ใช่ภาพระบบที่รันจริง และไม่รับรองว่า Feature ทุกส่วนเสร็จแล้ว
- โครงเมนู แบบฟอร์ม และฟังก์ชันอ้างอิงจากร่าง [หัวข้อ 3.7–3.8](../chapter-3-7-3-8-ui-design.md) และ Source Code ที่ตรวจในงานก่อนหน้า
- Dashboard เป็นแบบเสนอเพิ่มเติม ใช้ช่องว่างแทนตัวเลข ไม่สมมติข้อมูลประสิทธิภาพหรือผู้ใช้จริง
- User Management ใช้การเปิด–ปิดบัญชี ไม่มีปุ่มลบผู้ใช้ ส่วน Audit อ่านอย่างเดียว ไม่บันทึกทุกการคลิก
- Management State แยกจาก Reachability: สถานะการจัดการเลือกโดยผู้มีสิทธิ์ ส่วนการตรวจ SNMP เป็นผลสังเกตจากระบบ
- สิทธิ์จัดการ Devices/Discovery และการจัดการ Credential Profile ยังต้องตรวจการบังคับใช้ให้ตรงกับนโยบายก่อนส่งมอบระบบจริง ภาพนี้ไม่ใช่หลักฐานว่าปุ่มหรือ API ได้รับการป้องกันครบ
- Topology เป็นตัวอย่างรูปแบบการจัดวาง แสดงอุปกรณ์และเส้นเชื่อมสมมติ ไม่ยืนยันว่า Endpoint ทุกชนิดค้นหาได้จริงผ่าน Discovery
- ใช้ IP ตัวอย่าง `192.0.2.x` และอีเมล `example.test` ไม่มี Password, Token หรือข้อมูลเครือข่ายจริงในไฟล์
- รอบปรับ Edit Device วันที่ 16 ตุลาคม 2569 แก้เฉพาะแบบ Wireframe และคำอธิบายในรายงาน Google Docs ไม่เปลี่ยน Source Code แอปพลิเคชันและไม่รัน Discovery หรือ SNMP

## ไฟล์สำหรับปรับแบบต่อ

[build-wireframes.cjs](build-wireframes.cjs) สร้างไฟล์และภาพตัวอย่างจากองค์ประกอบต้นแบบ หากแก้ `.drawio` ด้วยมือแล้ว ไม่ควรรันไฟล์นี้ทับผลแก้ไข เพราะจะสร้างจากต้นแบบใหม่ ให้บันทึกไฟล์ที่แก้ด้วยมือเป็นชื่อใหม่ก่อน

การตรวจคุณภาพ: `render-qa.json` ตรวจขอบเขตและข้อความในภาพ PNG/SVG ที่ Render จาก XML จริงของ Draw.io ไม่ใช่การทดสอบระบบ MyNetMate
